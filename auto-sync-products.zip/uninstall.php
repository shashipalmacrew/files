<?php

/**
 * This file runs when the plugin is uninstalled.
*/ 

// Exit if not called by WordPress.
if (!defined('WP_UNINSTALL_PLUGIN')) {
	exit;
}

// Delete plugin options.

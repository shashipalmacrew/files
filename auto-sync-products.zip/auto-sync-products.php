<?php

// Exit if this file is accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Plugin Name:       Sync Products
 * Description:       To import/sync the wheels and tyres.
 * Version:           1.0.0
 * Author:            Macrew Technologies
 * License:           GPLv3
 */


/**
 *** How this plugin works and what it does:
 * 1) The plugin will create the sub menu page under woocommerce in the dashboard named Sync products.
 * 2) Adds a settings tab on sync products page in WordPress admin dashboard.
 */

// This plugin is for site administrators only, so we load the plugin only in admin mode.
if ( is_admin() ) {
    
    // Load plugin class code.
    require_once __DIR__ . '/sync_products/sync_products_settings.php';

    //plugin class instance.
    $syncProductsSettings = new syncProductsSettings( plugin_basename(__FILE__) );
    
}
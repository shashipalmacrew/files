function getSelector(int, state)
{
        return "fieldset.s" + int + "-" + state + " > input[type=radio]";
}
;

<?php
/**
 * Display custom text before the account orders on my account order view dashboard
 * Only on "My Account" > "Order View"
 */

add_action('woocommerce_order_details_before_order_table', 'action_order_details_after_order_table', 10, 4 );

function action_order_details_after_order_table( $order, $sent_to_admin = '', $plain_text = '', $email = '' ) {   
    
    require_once  __DIR__ . "/signature/BizMsgCrypt.php";

     if ( is_wc_endpoint_url( 'view-order' ) ) { 
        echo '<h2 class="custom-text">Track & Trace your order</h2>';

        $api_credentials = get_option('shipping_labels_tracking');

        $appKey = $api_credentials['appkey'];
        $encodingAesKey = $api_credentials['aeskey'];
        $appsecret = $api_credentials['appsecret'];        
        $client_customer_code = $api_credentials['client_Code'];

        //get access token
        $url = 'http://api-ifsp.sit.sf.global/openapi/api/token?appKey='.$appKey.'&appSecret='.$appsecret;   
        $ch = curl_init();   
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);   
        curl_setopt($ch, CURLOPT_URL, $url);   
        $res = curl_exec($ch);    

        $res_data = json_decode($res);

        $token = $res_data->apiResultData->accessToken;
        
        $timeStamp =time();
        $nonce ="123";

        $sfWaybillNo = get_post_meta($order->id, 'sfWaybillNo', true);


        $reqBody = "{\"customerCode\":\"$client_customer_code\",\"sfWaybillNo\":\"$sfWaybillNo\"}";

        $pc = new BizMsgCrypt($token, $encodingAesKey, $appKey);

        $result = $pc->encryptMsg($reqBody, $timeStamp, $nonce);
        //var_dump($result);

        $encrypt = $result['encrypt'];
        $signature = $result['signature'];

        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api-ifsp.sit.sf.global/openapi/api/dispatch',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $encrypt,
        CURLOPT_HTTPHEADER => array(
            'appKey:'.$appKey,
            'token:'.$token,
            'timestamp:'.$timeStamp,
            'nonce:'.$nonce,
            'signature:'.$signature,
            'msgType: IUOP_QUERY_TRACK',
            'lang: en',
            'Content-Type: application/json'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        $response_data = json_decode($response);

        $last_response = $pc->decryptMsg($timeStamp, $nonce, $response_data->apiResultData);
        $array_response = json_decode($last_response[1]);

        $sfWaybillNo = $array_response->data[0]->sfWaybillNo;

        echo '<p><strong>SfWay bill No: </strong>'.$sfWaybillNo.'</p>';

        echo '<p><span lang="EN-US">You can check it on the website&nbsp;</span><span lang="EN-US"><a href="http://www.sf-express.com/th/en/">http://www.sf-express.com/th/en/</a></span><span lang="EN-US">. Type&nbsp;in the tracking number under "Track and Trace", click "Search", and you will have the information of your shipment. Additionally, you can contact at their hotline&nbsp;<strong>02 295 1889</strong>&nbsp;for inquiry as well.&nbsp;</span></p>';

    } 
}

?>
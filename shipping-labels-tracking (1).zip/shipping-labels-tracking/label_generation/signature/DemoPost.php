<?php
namespace com\sf\ibu;

include_once "BizMsgCrypt.php";

// 第三方发送消息
$encodingAesKey = "dcLutUPXvxDjzVDgLV0SsAI5UAxmEloNHEZVtgxnvuA";
$token = "auth_d830f571-570a-44e7-a51a-c49b1ec6d79f_1637927849980";
$timeStamp = "1637927849983";
$nonce = "1637927849983";
$appKey = "76a5c52b9027505f4fcc4c358fb58211";
$pc = new BizMsgCrypt($token, $encodingAesKey, $appKey);

header('Content-Type:text/xml; charset=utf-8');

if(isset($_POST['text_de']) && $_POST['text_de'] != ""){
    $text = $_POST['text_de'];
    $result = $pc->encryptMsg($text, $timeStamp, $nonce);
    exit($result['encrypt']);
}

if(isset($_POST['text_en']) && $_POST['text_en'] != ""){
    $encrypt = $_POST['text_en'];
    $deResult = $pc->decryptMsg($timeStamp, $nonce, $encrypt);
    var_dump($deResult);
    exit($deResult[1]);
}

<?php
/* 
*Included this label.php file in lead_generation.php to print label
*/

$api_credentials = get_option('shipping_labels_tracking');

/* Live api creds (If live creds enabled) */
if($api_credentials['enable_live_creds'] == 'on'){
   $appKey = $api_credentials['liveappkey'];
   $encodingAesKey = $api_credentials['liveaeskey'];
   $appsecret = $api_credentials['liveappsecret'];   
   $client_customer_code = $api_credentials['liveclient_Code'];
   $token_api_url = 'https://api-ifsp.sf.global/openapi/api/token?appKey='.$appKey.'&appSecret='.$appsecret; 
   $create_order_url = 'https://api-ifsp.sf.global/openapi/api/dispatch';
   $payMonthCard = $api_credentials['payMonthCard']; // Live month card value from api profile
   
}else{
   /* Sandbox api creds */
   $appKey = $api_credentials['appkey'];
   $encodingAesKey = $api_credentials['aeskey'];
   $appsecret = $api_credentials['appsecret'];   
   $client_customer_code = $api_credentials['client_Code'];   
   $token_api_url = 'http://api-ifsp.sit.sf.global/openapi/api/token?appKey='.$appKey.'&appSecret='.$appsecret;
   $create_order_url = 'https://api-ifsp.sit.sf.global/openapi/api/dispatch';   
   $payMonthCard = "0270000250"; //sandbox month card static dummy value
    
}

//Other settings options
$declaredcurrency = $api_credentials['declaredcurrency'];
$countrycode = $api_credentials['countrycode'];   
$telareacode = $api_credentials['telareacode'];  
$phonenumber = $api_credentials['phonenumber'];

$timeStamp =time();
$nonce ="123"; 

//get access token 
$ch = curl_init();   
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);   
curl_setopt($ch, CURLOPT_URL, $token_api_url);   
$res = curl_exec($ch);    

$res_data = json_decode($res);

$token = $res_data->apiResultData->accessToken;

function generateRandomString($length = 10) {
   $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
   $charactersLength = strlen($characters);
   $randomString = '';
   for ($i = 0; $i < $length; $i++) {
       $randomString .= $characters[rand(0, $charactersLength - 1)];
   }
   return $randomString;
}

$customer_code_random = 'CUS'.generateRandomString();

$billing_postcode = get_post_meta($order_id, '_billing_postcode', true);

$order_billing_email = get_post_meta($order_id, '_billing_email', true);

$admin_email = get_option( 'admin_email' );

$user = get_user_by( 'email', $admin_email );

$admin_id = $user->ID;


$admin_address = get_user_meta( $admin_id, 'billing_address_1', true ); 
$admin_city = get_user_meta( $admin_id, 'billing_city', true ); 
$admin_state = get_user_meta( $admin_id, 'billing_state', true ); 
$admin_country = get_user_meta( $admin_id, 'billing_country', true ); 
$admin_phone = get_user_meta( $admin_id, 'billing_phone', true ); 

$admin_username = $user->username;

$pieces = $order->get_item_count();

// Getting an instance of the WC_Order object from a defined ORDER ID
$order = wc_get_order( $order_id ); 

$jayParsedAry = [
   "cargoTypeCode" => "C223", 
   "customerCode" => $client_customer_code,  //client code in credentials
   //"declaredCurrency" => "SGD", 
   "declaredCurrency" => $declaredcurrency, 
   "declaredValue" => 10, 
   "orderNo" => $order_id, 
   "orderOperateType" => "1",  // 1 to add order, 5 to change/update order
   "parcelQuantity" => $pieces,  
   "parcelTotalWeight" => 0.5, 
   "parcelWeightUnit" => "KG", 
   "parcelVolumeUnit" => "CM", 
   "parcelTotalLength" => "1", 
   "parcelTotalWidth" => "1", 
   "parcelTotalHeight" => "1", 
   "pickupAppointTime" => "", 
   "pickupAppointTimeZone" => "", 
   "pickupType" => "0", 
   "remark" => "", 
   "sfWaybillNo" => "", 
   "version" => "", 
   "customerOrderNo" => $order_id,        
   "customerOrderNoTwo" => "", 
   "interProductCode" => "INT0014", 
   "isBbd" => 0, 
   "agentWaybillNo" => "", 
   "paymentInfo" => [
      "payMethod" => "1", 
      "payMonthCard" => $payMonthCard, 
      "taxPayMethod" => "2", 
      "taxPayMonthCard" => "" 
   ], 
"addServiceInfoList" => [
  [
   "serviceCode" => "", 
   "value" => "", 
   "valueOne" => "" 
  ] 
], 
"customsInfo" => [
"aesNo" => "", 
"businessRemark" => "", 
"customsBatch" => "", 
"harmonizedCode" => "", 
"senderReasonContent" => "", 
"tradeCondition" => "" 
], 
"orderExtendInfo" => [
"isSelfPick" => "1", // 1 = self pick up, 0 courier 
"isSignBack" => "", 
"signBackWaybillNo" => "", 
"businessMode" => "0", 
"senderDeptCode" => "755A", 
"operEmpCode" => "000212" 
], 
"receiverInfo" => [
   "address" => $order_address_1.', '.$order_address_2, 
   "cargoType" => 1, 
   //"certCardNo" => "430527199309204211", 
   //"certType" => "001", 
   "city" => $order_city, 
   //"company" => $order_company, 
   "contact" => $order_first_name.' '.$order_last_name, 
   "country" => $countrycode,  
   "email" => $order_billing_email, 
   "eori" => "", 
   //"phoneAreaCode" => "", 
   "phoneNo" => $order_phone, 
   "postCode" => $billing_postcode, 
   "province" => $order_state, 
   "telAreaCode" => $telareacode, 
   "telNo" => $order_phone, 
   "vat" => "" 
   ], 
"senderInfo" => [
"address" => $admin_address, 
"cargoType" => 1, 
"certCardNo" => "", 
"certType" => "001", 
"city" => $admin_city,  
//"company" => "", 
"contact" => site_url(), 
"country" => $countrycode, 
"email" => $admin_email, 
"eori" => "", 
"phoneAreaCode" => $telareacode, 
"phoneNo" => $phonenumber, 
"postCode" => $billing_postcode, 
"province" => $admin_state, 
"telAreaCode" => $billing_postcode, 
"telNo" => $phonenumber, 
"vat" => "" 
], 

"ecommerceInfo" => [
//"actPay" => 1221, 
//"applicationNo" => "1231231321", 
"buyerEmail" => $order_billing_email, 
//"buyerFreight" => 123132, 
"buyerNickname" => $order_first_name, 
//"buyerPremium" => 122, 
//"currency" => "TWD", 
//"enterpriseCheckCode" => "1232", 
//"enterpriseCrossCode" => "12342", 
"enterpriseCustomsCode" => "", 
"enterpriseName" => "", 
//"payEnterpriseCheckCode" => "22212", 
//"payEnterpriseCustomsCode" => "22222", 
"payNo" => "", 
"payTime" => "", 
"payToolType" => "", 
"payerCertNo" => "", 
"payerCertType" => "", 
"payerName" => "", 
"payerTel" => "", 
"platformCheckCode" => "", 
"platformCustomsCode" => "", 
"platformDomainName" => site_url(), 
"platformName" => "", 
"preferentialAmount" => '', 
"promotionType" => "1", 
"sellerAlipayNo" => "", 
"sellerEmail" => $admin_email, 
"sellerNickname" => $admin_username, 
"shopWebCode" => "", 
"storeCode" => "", 
"tax" => "" 
] 
]; 

$jayParsedAry['parcelInfoList'] = array();
// Iterating through each "line" items in the order      
foreach ($order->get_items() as $item_id => $item ) {

   // Get an instance of corresponding the WC_Product object
   $product        = $item->get_product();

   $active_price   = $product->get_price(); // The product active raw price

   $regular_price  = $product->get_sale_price(); // The product raw sale price

   $sale_price     = $product->get_regular_price(); // The product raw regular price

   $product_name   = $item->get_name(); // Get the item name (product name)

   $item_quantity  = $item->get_quantity(); // Get the item quantity

   $item_subtotal  = $item->get_subtotal(); // Get the item line total non discounted

   $item_subto_tax = $item->get_subtotal_tax(); // Get the item line total tax non discounted

   $item_total     = $item->get_total(); // Get the item line total discounted

   $item_total_tax = $item->get_total_tax(); // Get the item line total  tax discounted

   $item_taxes     = $item->get_taxes(); // Get the item taxes array

   $item_tax_class = $item->get_tax_class(); // Get the item tax class

   $item_tax_status= $item->get_tax_status(); // Get the item tax status

   $item_downloads = $item->get_item_downloads(); // Get the item downloads

   $jayParsedAry['parcelInfoList'][] = ["amount" => $active_price, 
   "brand" => "", 
   "currency" => "", 
   "goodsCode" => "", 
   "goodsDesc" => "", 
   "goodsUrl" => "", 
   "hsCode" => "", 
   "name" => $product_name, 
   //"originCountry" => "SG", 
   "productCustomsNo" => "", 
   "productRecordNo" => "", 
   "quantity" => $item_quantity, 
   "stateBarCode" => "", 
   "unit" => "个"]; 

}

/* echo "<pre>Response ";
print_r($jayParsedAry);
echo "</pre>Response End "; */

$reqBody = json_encode($jayParsedAry);

$pc = new BizMsgCrypt($token, $encodingAesKey, $appKey);

$result = $pc->encryptMsg($reqBody, $timeStamp, $nonce);

$encrypt = $result['encrypt'];
$signature = $result['signature']; 



/* sdfsdf */
/*  echo $token_api_url.'</br>'; 
echo 'create_url:'.$create_order_url.'</br>';
echo 'appKey:'.$appKey.'</br>';
echo 'token:'.$token.'</br>';
echo 'timeStamp:'.$timeStamp.'</br>';
echo 'nonce:'.$nonce.'</br>';
echo 'signature:'.$signature.'</br>';

echo 'post fields: '.$encrypt.'</br>'; */
//die;



$curl = curl_init();

curl_setopt_array($curl, array(
CURLOPT_URL => $create_order_url,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_ENCODING => '',
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 0,
CURLOPT_FOLLOWLOCATION => true,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => 'POST',
CURLOPT_POSTFIELDS => $encrypt,
CURLOPT_HTTPHEADER => array(
'appKey:'.$appKey,
'token:'.$token,
'timestamp:'.$timeStamp,
'nonce:'.$nonce,
'signature:'.$signature,
'msgType: IUOP_CREATE_ORDER',
'lang: en',
'Content-Type: application/json'
),
));

$response = curl_exec($curl);
curl_close($curl);

$response_data = json_decode($response);

//print_r($response_data);

$last_response = $pc->decryptMsg($timeStamp, $nonce, $response_data->apiResultData);

//print_r($last_response);

$array_response = json_decode($last_response[1]);

 /* echo '<pre>';
print_r($array_response);
echo '</pre>'; */ 

//die;

$invoiceUrl = get_post_meta($order_id, 'invoice_url', true);

/* print label if the label response is not null */
if($array_response->success){
   $invoiceUrl = $array_response->data->invoiceUrl;
   $labelUrl = $array_response->data->labelUrl;
   $customerOrderNo = $array_response->data->customerOrderNo;
   $sfWaybillNo = $array_response->data->sfWaybillNo;

   update_post_meta($order_id, 'invoice_url', $invoiceUrl);
   update_post_meta($order_id, 'label_url', $labelUrl);
   update_post_meta($order_id, 'sfWaybillNo', $sfWaybillNo);

   echo '<p><strong>sfWaybillNo: </strong>'.$sfWaybillNo.'</p>';
   //echo '<a href="'.$invoiceUrl.'" target="_blank" class="print-link">Print invoice</a>';
   echo '<a href="'.$labelUrl.'" target="_blank" class="button save_order button-primary print-link"><span class="dashicons dashicons-pdf">Print labels</span></a>';
   echo '<p><a href="http://www.sf-express.com/th/en/" target="_blank">Track order</a></p>';
}
elseif($invoiceUrl !=''){ /* if label already generated then get from DB */
				$invoiceUrl = get_post_meta($order_id, 'invoice_url', true);
				$labelUrl = get_post_meta($order_id, 'label_url', true);
				$sfWaybillNo = get_post_meta($order_id, 'sfWaybillNo', true);

            echo 'Labels are already Generated, no changes can be made in the order! If you want to change any thing in the invoice and label then you need to cancel this order and create a new order and then new labels can be generated!!';
				echo '<p><strong>sfWaybillNo: </strong>'.$sfWaybillNo.'</p>';
				//echo '<a href="'.$invoiceUrl.'" target="_blank" class="print-link">Print invoice</a>';
				echo '<a href="'.$labelUrl.'" target="_blank" class="button save_order button-primary print-link"><span class="dashicons dashicons-pdf">Print labels</span></a>';
            echo '<p><a href="http://www.sf-express.com/th/en/" target="_blank">Track order</a></p>';
}else{ /* Else label is already generated */
   echo $array_response->msg;
}

?>
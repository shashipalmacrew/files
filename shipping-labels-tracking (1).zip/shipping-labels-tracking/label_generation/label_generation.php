<?php

// Exit if this file is accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;	


/*error_reporting(E_ALL); 
ini_set("display_errors", 1);*/

/**
 * This plugin add button in WooCommerce orders page,
 * to generate a shipping label.
 */
class shippingLabelstracking {

	  //////////////////////////////////////////////////
	 /// Default label settings and class constants ///
	//////////////////////////////////////////////////
	// Plugin and settings slugs/names/ids/... used in the functions below.
	const PLUGIN_VERSION = '1.0.0';
	const PLUGIN_NAME = 'Shipping Labels and Tracking';
	const OPTION_GROUP_NAME = 'sslabels_plugin_options';
	const OPTION_NAME = 'shipping_labels_tracking';
	const SETTINGS_PAGE_SLUG = 'label_settings';
	const SETTINGS_PAGE_SECTION_SLUG = 'general';

	// Settings sections slugs.
	const LABEL_SETTINGS_SECTION_SLUG = 'label-settings';
	const BRAND_SETTINGS_SECTION_SLUG = 'brand-settings';
	const RECIPIENT_SETTINGS_SECTION_SLUG = 'recipient-settings';
	const ORDER_SETTINGS_SECTION_SLUG = 'order-settings';

	/*** Plugin settings ***/
	public $settings = array();
	public $default_settings = array(
		'appkey'				    =>	'',
		'appsecret'				    =>	'',
		'aeskey'				    =>	'',
		'client_Code'				=>	'',		
		'liveappkey'            	=>  '',
		'liveappsecret'        		=>  '',
		'liveaeskey'            	=>  '',
		'liveclient_Code'           =>  '',
		'payMonthCard'              =>  '',
		'declaredcurrency'          =>  '',
		'countrycode'               =>  '',
		'telareacode'               =>  '',
		'phonenumber'               =>  '',
		'label_height'				=>	53,		// mm
		'label_width'				=>	101,	// mm
		'label_padding_vertical'	=>	2,		// mm
		'label_padding_horizontal'	=>	2,		// mm
		'test_labels'				=>	'',	// list of order ids to generate labels for preview
		'recipient_details_layout'	=>	'default',	// selected radio button
		'recipient_align_fields'	=>	'center',	// selected dropdown option
		'use_billing_details'		=>	'on',	// checked checkbox
		'show_company'				=> 	'off',	// checked checkbox
		'display_state_full_name'	=>	'on',	// checked checkbox
		'hide_base_country'			=>	'on',	// checked checkbox
		'show_phone'				=> 	'on',	// checked checkbox
		'show_order_total'			=>	'off',	// unchecked checkbox
		'show_order_id'				=> 	'on',	// checked checkbox
		'enable_live_creds'         => 	'off',	// unchecked checkbox
		'plugin_version'			=> 	self::PLUGIN_VERSION	// currently not used in plugin
	);

	public $recipient_align_fields_options = ['center','left','right'];
	public $recipient_details_layout_options = array(
		'default' => "<br><span class='label-layout-title'><b>DEFAULT</b></span><br>first_name last_name<br>company<br>address_1 address_2<br>city state post_code<br>country<br>phone",
		'separate_lines' => "<br><span class='label-layout-title'><b>SEPARATE LINES:</b></span><br>first_name last_name<br>company<br>address_1 address_2<br>city<br>state<br>post_code<br>country<br>phone",
		'post_code_first' => "<br><span class='label-layout-title'><b>POST CODE FIRST</b></span><br>first_name last_name<br>company<br>address_1 address_2<br>post_code city state<br>country<br>phone",
		'post_code_first_separate_lines' => "<br><span class='label-layout-title'><b>POST CODE FIRST<br>SEPARATE LINES</b></span><br>first_name last_name<br>company<br>address_1 address_2<br>post_code<br>city<br>state<br>country<br>phone",
	);


	  ////////////////////////////////////////////////
	 /// Class constructor, methods and callbacks ///
	////////////////////////////////////////////////
	/**
	 * The plugin class constructor is responsible for:
	 * - Getting saved plugin options from wp_options database table or using the $default_settings array above.
	 * - Registering plugin hooks:
	 *   - Run plugin update routine when plugin loads.
	 *   - Add settings page to the admin menu.
	 *   - Add buttons and JavaScript to WooCommerce orders page to generate labels.
	 *   - Register custom AJAX endpoint (a single function acts as plugin api) to generate labels page or reset plugin options.
	 */
	public function __construct( $plugin_basename )
    {
		// #######################
		// ### WordPress hooks ###
		// #######################
		// Add plugin version check and update routine.
		// This hook runs each time the plugin is loaded (wordpress environment loads),
		// because there are no other reliable hooks that run when plugin files are
		// updated from remote server.
		add_action('plugins_loaded', array( $this, 'load_plugin_settings' ) );

		// Add plugin settings page ("options page") and register settings.
		add_action( 'admin_menu', array( $this, 'add_plugin_options_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		// Add plugin action link to the plugin settings page.
		// Action links displayed for a specific plugin in the Plugins list table.
		add_filter( 'plugin_action_links_' . $plugin_basename, array( $this, 'my_plugin_action_links' ) );

		// Register AJAX endpoint as plugin API to generate labels or reset settings to default.
		add_action( 'wp_ajax_sslabels_api', array( $this, 'sslabels_api' ) );


		// #########################
		// ### WooCommerce hooks ###
		// #########################
		// Add custom column to WooCommerce orders table page.
		
		//add_filter( 'manage_edit-shop_order_columns', array( $this, 'add_print_buttons_column' ) );

		// Populate the column with print buttons.
		//add_action( 'manage_shop_order_posts_custom_column', array( $this, 'add_print_buttons' ) );

		// Add JavaScript functionality to the buttons.
		add_action( 'admin_enqueue_scripts', array( $this, 'add_admin_pages_scripts_and_styles' ) );

		// Add shipping label meta box for print button to all order types (based on WooCommerce plugin source code woocommerce/includes/admin/class-wc-admin-meta-boxes.php file).
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ), 30 );
	}

	// Add plugin action link to plugin settings page.
	function my_plugin_action_links( $actions ) {
		$myActions = array( '<a href="'. esc_url( admin_url('admin.php?page=' . self::SETTINGS_PAGE_SLUG) ) .'">' . __('Settings') . '</a>',);
		return array_merge( $myActions, $actions );
	}

	  /////////////////////////////
	 /// ADMIN EDIT ORDER PAGE ///
	/////////////////////////////
	function add_meta_boxes() {
		foreach ( wc_get_order_types( ['order-meta-boxes'] ) as $type ) {
			$order_type_object = get_post_type_object( $type );
			add_meta_box( 'woocommerce-order-shipping-label', __( 'Shipping Labels', 'woocommerce' ) . wc_help_tip( 'Generate shipping label and invoice' ), array( $this, 'add_admin_order_page_meta_box' ), $type, 'side', 'high' );
		}
	}

	function add_admin_order_page_meta_box() {
		/*
		// Check which admin screen we are on.
		$current_screen = get_current_screen();
		echo $current_screen->post_type;
		*/

		global $post;

		// Get an instance of the WC_Order Object (if needed).
		//$order = wc_get_order( $post->ID );

		// Metabox button uses the same enqued script
		$shipping_label_print_button_html = '<button type="button" class="button button-sslabels-print" '
		. 'value="' . $post->ID . '">'. __( 'Label' ) .'</button>';
		echo $shipping_label_print_button_html;
	}

	  ////////////////////////////
	 /// PLUGIN SETTINGS PAGE ///
	////////////////////////////
	/**
	 * Add plugin settings page in WooCommerce plugin submenu.
	 */
	function add_plugin_options_page() {
		add_submenu_page(
			'woocommerce',									// $parent_slug
			self::PLUGIN_NAME,								// $page_title
			self::PLUGIN_NAME,								// $menu_title
			'manage_options',								// $capability
			self::SETTINGS_PAGE_SLUG,						// $menu_slug
			array( $this, 'render_plugin_settings_page' )	// callable $function
		);
	}

	/**
	 * Output the plugin settings page HTML.
	 * The settings page is a simple form, which is submitted to options.php.
	 * The form fields rendered via do_settings_sections() callback.
	 * The settings are saved in wp_options database table under a single serialized
	 * option with a name self::OPTION_NAME.
	 */
	function render_plugin_settings_page() {
		?>
		<!-- Admin page content should all be inside .wrap class for some reason -->
		
		<h1 class="shipping-setting-title"><?php echo esc_html( get_admin_page_title() ); ?></h1>

		<div class="wrap">
			<!-- Echo the page title -->
			<p>Shipping label parameters for <b>WooCommerce</b> <a href="<?php echo site_url() ?>/wp-admin/edit.php?post_type=shop_order">orders</a>.</p>
			<nav class="nav-tab-wrapper">
				<a href="#tab-label" id="sslabels-settings-tab-label" class="nav-tab nav-tab-active">Label</a>
				<!-- <a href="#tab-recipient" id="sslabels-settings-tab-recipient" class="nav-tab">Recipient</a>
				<a href="#tab-order" id="sslabels-settings-tab-order" class="nav-tab">Order</a> -->
			</nav>
			<form action="options.php" method="post">
				<?php
					settings_fields( self::OPTION_GROUP_NAME );			// Output nonce, action, and option_page fields for a settings page.

					// Output all sections at once via WordPress native settings output funciton.
					// do_settings_sections( self::SETTINGS_PAGE_SLUG );	// Prints out all settings sections added to a particular settings page.

					// Label settings tab.
					echo '<div id="tab-label" class="sslabels-settings-form-tab sslabels-active"><table class="form-table">';
					do_settings_fields( self::SETTINGS_PAGE_SLUG, self::LABEL_SETTINGS_SECTION_SLUG );
					echo '</table></div>';

					// Recipient settings tab.
					echo '<div id="tab-recipient" class="sslabels-settings-form-tab"><table class="form-table">';
					do_settings_fields( self::SETTINGS_PAGE_SLUG, self::RECIPIENT_SETTINGS_SECTION_SLUG );
					echo '</table></div>';

					// Order settings tab.
					echo '<div id="tab-order" class="sslabels-settings-form-tab"><table class="form-table">';
					do_settings_fields( self::SETTINGS_PAGE_SLUG, self::ORDER_SETTINGS_SECTION_SLUG );
					echo '</table></div>';
				?>
				<input type="submit" name="submit" class="button button-primary"  value="Save"/>
				<button type="button" id="button-reset-settings" class="button">Reset settings</button>
			</form>
		</div>
		<script>
			var delete_settings_button = document.querySelector("#button-reset-settings");
			delete_settings_button.addEventListener('click', function() {

				// Make sure the user wants to delete saved plugin settings.
				if (!confirm("Delete saved plugin options and reset settings?")) {
					return;
				}

				// Show progress in button text.
				this.disabled = true;
				this.innerHTML = "Deleting saved plugin options...";

				// Send AJAX request to plugin API to reset plugin settings.
				var data = {
					'action': 'sslabels_api',
					'api_action': 'reset_options',
					'_ajax_nonce': '<?php echo wp_create_nonce('reset_options') ?>'
				};

				// Since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php.
				jQuery.post(ajaxurl, data, function(response) {
					location.reload();
				}).fail(function() {
					alert( "Could not delete saved plugin options. Please try again later or contact plugin support." );
					console.error(response);
					delete_settings_button.innerHTML = "Reset settings";
					delete_settings_button.disabled = false;
				});
			});
		</script>

		<?php
	}


	/**
	 * Register a single setting/option to store all plugin settings.
	 */
	function register_settings() {

		// Register the setting and data validation filter function.
		register_setting( self::OPTION_GROUP_NAME, self::OPTION_NAME, array( $this, 'plugin_options_validate' ) );

		// Label general settings section.
		add_settings_section( self::LABEL_SETTINGS_SECTION_SLUG, 'Label settings', array( $this, 'settings_section_text' ), self::SETTINGS_PAGE_SLUG );


		add_settings_field( 'setting_enable_live_credentials', 'Enable Live Mode', array( $this, 'setting_enable_live_creds'), self::SETTINGS_PAGE_SLUG, self::LABEL_SETTINGS_SECTION_SLUG );
		add_settings_field( 'sandbox-api-credentials', 'Sandbox Api Credentials', array( $this, 'sandbox_api_options_settings'), self::SETTINGS_PAGE_SLUG, self::LABEL_SETTINGS_SECTION_SLUG );
		add_settings_field( 'live-api-credentials', 'Live Api Credentials', array( $this, 'live_api_options_settings'), self::SETTINGS_PAGE_SLUG, self::LABEL_SETTINGS_SECTION_SLUG );
		add_settings_field( 'options-api-credentials', 'Options Api Credentials', array( $this, 'api_options_settings'), self::SETTINGS_PAGE_SLUG, self::LABEL_SETTINGS_SECTION_SLUG );

		/*add_settings_field( 'label-size', 'Label size', array( $this, 'setting_label_size'), self::SETTINGS_PAGE_SLUG, self::LABEL_SETTINGS_SECTION_SLUG );
		add_settings_field( 'label-padding', 'Label padding', array( $this, 'setting_label_padding' ), self::SETTINGS_PAGE_SLUG, self::LABEL_SETTINGS_SECTION_SLUG ); */
		


		// Recipient address settings section.
		add_settings_section( self::RECIPIENT_SETTINGS_SECTION_SLUG, 'Recipient/order address section', array( $this, 'settings_section_text' ), self::SETTINGS_PAGE_SLUG );
		add_settings_field( 'recipient_details_layout', 'Details layout', array( $this, 'setting_recipient_details_layout'), self::SETTINGS_PAGE_SLUG, self::RECIPIENT_SETTINGS_SECTION_SLUG );
		add_settings_field( 'recipient_details_align', 'Details text align', array( $this, 'setting_recipient_details_align'), self::SETTINGS_PAGE_SLUG, self::RECIPIENT_SETTINGS_SECTION_SLUG );
		add_settings_field( 'recipient_use_billing_details', 'Use billing details', array( $this, 'setting_recipient_use_billing_details'), self::SETTINGS_PAGE_SLUG, self::RECIPIENT_SETTINGS_SECTION_SLUG );
		add_settings_field( 'recipient_show_company', 'Company', array( $this, 'setting_recipient_show_company'), self::SETTINGS_PAGE_SLUG, self::RECIPIENT_SETTINGS_SECTION_SLUG );
		add_settings_field( 'recipient_display_state_full_name', 'State abbreviations', array( $this, 'setting_recipient_display_state_full_name'), self::SETTINGS_PAGE_SLUG, self::RECIPIENT_SETTINGS_SECTION_SLUG );
		add_settings_field( 'recipient_hide_base_country', 'Local shipping', array( $this, 'setting_recipient_hide_base_country'), self::SETTINGS_PAGE_SLUG, self::RECIPIENT_SETTINGS_SECTION_SLUG );
		add_settings_field( 'recipient_show_phone', 'Phone', array( $this, 'setting_recipient_show_phone'), self::SETTINGS_PAGE_SLUG, self::RECIPIENT_SETTINGS_SECTION_SLUG );


		// Order settings section.
		add_settings_section( self::ORDER_SETTINGS_SECTION_SLUG, 'Order details section', array( $this, 'settings_section_text' ), self::SETTINGS_PAGE_SLUG );
		add_settings_field( 'order_show_id', 'Order id', array( $this, 'setting_order_show_id'), self::SETTINGS_PAGE_SLUG, self::ORDER_SETTINGS_SECTION_SLUG );
		add_settings_field( 'order_show_total', 'Order total', array( $this, 'setting_order_show_total'), self::SETTINGS_PAGE_SLUG, self::ORDER_SETTINGS_SECTION_SLUG );
	}


	/**
	 * Sanitize and validate plugin settings page form fields.
	 */
	function plugin_options_validate( $input ) {

		// Sanitize and validate user plugin settings.
		$sanitized_and_validated_input = array(
			'appkey'                    => $input['appkey'],
			'appsecret'                 => $input['appsecret'],
			'aeskey'                    => $input['aeskey'],
			'client_Code'                => $input['client_Code'],
			'liveappkey'                    => $input['liveappkey'],
			'liveappsecret'                 => $input['liveappsecret'],
			'liveaeskey'                    => $input['liveaeskey'],
			'liveclient_Code'                => $input['liveclient_Code'],
			'payMonthCard'                => $input['payMonthCard'],	
			'declaredcurrency'          =>  $input['declaredcurrency'],
			'countrycode'               =>  $input['countrycode'],
			'telareacode'               =>  $input['telareacode'],	
			'phonenumber'               => 	$input['phonenumber'],
			'label_height'				=>	absint( $input['label_height'] ),
			'label_width'				=>	absint( $input['label_width'] ),
			'label_padding_vertical'	=>	absint( $input['label_padding_vertical'] ),
			'label_padding_horizontal'	=>	absint( $input['label_padding_horizontal'] ),
			'test_labels'				=>	wp_parse_id_list( $input['test_labels'] ),
			'plugin_version'			=> 	self::PLUGIN_VERSION,	// Add plugin version to the stored plugin settings option.
		);

		// If checkboxes are checked - they exist in $input array and we add them to $sanitized_input,
		// otherwise they were either turned off, or they didn't exist in previous plugin version.
		// We handle the later case by explicitly setting them to 'off' when the user saves settings, so if they don't exist
		// when plugin is loaded - the default settings are applied and stored in database.

		// Because of a known WordPress bug - this option sanitization callback is called twice if option doesn't exist.
		// https://core.trac.wordpress.org/ticket/21989
		// So if you count on using only isset() to check if some key exists in $input and then set it - this same
		// callback will be called again on the $sanitized_and_validated_input we return here, and run again! So isset()
		// will look like it always returns 'true' (because you set it in previous callback call).
		// To see it for yourself - add the following line:
		// $sanitized_and_validated_input['test'] = $input;
		// and observe the initial saved database option (or after resetting/removing the option) vs saving again and again.

		$checkboxes = [
			'show_company',
			'display_state_full_name',
			'hide_base_country',
			'show_phone',
			'show_order_id',
			'show_order_total',
			'use_billing_details',
			'enable_live_creds'
		];

		foreach ($checkboxes as $checkbox) {
			$sanitized_and_validated_input[$checkbox] = (!empty($input[$checkbox]) && $input[$checkbox] == 'on') ? 'on' : 'off' ;
		}

		// Validate the recipient_details_layout selected radio option is one of the available options, otherwise use the default setting.
		if ( !empty($input['recipient_details_layout'])  && !empty($this->recipient_details_layout_options[$input['recipient_details_layout']]) )  {
			$sanitized_and_validated_input['recipient_details_layout'] = $input['recipient_details_layout'];
		} else {
			$sanitized_and_validated_input['recipient_details_layout'] = $this->$default_settings['recipient_details_layout'];
		}

		// Validate the recipient_align_fields option is one of the available options, otherwise use the default setting.
		if ( !empty( $input['recipient_align_fields'] ) && in_array( $input['recipient_align_fields'], $this->recipient_align_fields_options, true) ) {		// `true` enables strict type checking
			$sanitized_and_validated_input['recipient_align_fields'] = $input['recipient_align_fields'];
		} else {
			$sanitized_and_validated_input['recipient_align_fields'] = $this->$default_settings['recipient_align_fields'];
		}

		// Return the sanitized and validated input (plugin settings) to save as option in wp_options database table.
		return $sanitized_and_validated_input;
	}


	  ////////////////////////////////////////////////
	 /// PLUGIN SETTINGS PAGE SECTIONS AND FIELDS ///
	////////////////////////////////////////////////
	function settings_section_text() {
		// echo "<p>This is section text.</p>";
	}

	// ###############
	// ####Sandbox Api settings ####
	// ###########

	function sandbox_api_options_settings(){
		?>
		<ul class="field-type">
			<li>
				<label for="appkey">AppKey :</label>
				<input id="appkey" name="<?php echo self::OPTION_NAME; ?>[appkey]" type="text" value="<?php echo esc_attr( $this->settings['appkey'] ); ?>" />
				
			</li>
			<li>
				<label for="appsecret">Appsecret :</label>
				<input id="appsecret" name="<?php echo self::OPTION_NAME; ?>[appsecret]" type="text" value="<?php echo esc_attr( $this->settings['appsecret'] ); ?>" />
				
			</li>
			<li>
				<label for="aeskey">AesKey:</label>
				<input id="aeskey" name="<?php echo self::OPTION_NAME; ?>[aeskey]" type="text" value="<?php echo esc_attr( $this->settings['aeskey'] ); ?>" />
				
			</li>
			<li>
				<label for="client_Code">ClientCode:</label>
				<input id="client_Code" name="<?php echo self::OPTION_NAME; ?>[client_Code]" type="text" value="<?php echo esc_attr( $this->settings['client_Code'] ); ?>" />
				
			</li>
		</ul>
		<!-- <p class="description"><b>Note:</b> if you find empty labels (page overflows) in print dialogue - use 1mm less height.</p> -->

		<?php
	}

	// ###############
	// ####Live Api settings ####
	// ###########

	function live_api_options_settings(){
		?>
		<ul class="field-type">
			<li>
				<label for="live_appkey">AppKey :</label>
				<input id="live_appkey" name="<?php echo self::OPTION_NAME; ?>[liveappkey]" type="text" value="<?php echo esc_attr( $this->settings['liveappkey'] ); ?>" />
				
			</li>
			<li>
				<label for="live_appsecret">Appsecret :</label>
				<input id="live_appsecret" name="<?php echo self::OPTION_NAME; ?>[liveappsecret]" type="text" value="<?php echo esc_attr( $this->settings['liveappsecret'] ); ?>" />
				
			</li>
			<li>
				<label for="live_aeskey">AesKey:</label>
				<input id="live_aeskey" name="<?php echo self::OPTION_NAME; ?>[liveaeskey]" type="text" value="<?php echo esc_attr( $this->settings['liveaeskey'] ); ?>" />
				
			</li>
			<li>
				<label for="live_client_Code">ClientCode:</label>
				<input id="live_client_Code" name="<?php echo self::OPTION_NAME; ?>[liveclient_Code]" type="text" value="<?php echo esc_attr( $this->settings['liveclient_Code'] ); ?>" />
				
			</li>
			<li>
				<label for="payMonthCard">PayMonthCard:</label>
				<input id="payMonthCard" name="<?php echo self::OPTION_NAME; ?>[payMonthCard]" type="text" value="<?php echo esc_attr( $this->settings['payMonthCard'] ); ?>" />
				
			</li>

			
		</ul>
		<!-- <p class="description"><b>Note:</b> if you find empty labels (page overflows) in print dialogue - use 1mm less height.</p> -->

		<?php
	}


	// ###############
	// ####Api options settings ####
	// ###########

	function api_options_settings(){
		?>
		<ul class="field-type">
			<li>
				<label for="declaredcurrency">Declared Currency :</label>
				<input id="declaredcurrency" name="<?php echo self::OPTION_NAME; ?>[declaredcurrency]" placeholder="Example SGD" type="text" value="<?php echo esc_attr( $this->settings['declaredcurrency'] ); ?>" required/>
				
			</li>
			<li>
				<label for="phonenumber">Phone Number :</label>
				<input id="phonenumber" name="<?php echo self::OPTION_NAME; ?>[phonenumber]" type="tel" placeholder="Please enter 10 digits" pattern="[0-9]{3}[0-9]{3}[0-9]{4}" maxlength="10" value="<?php echo esc_attr( $this->settings['phonenumber'] ); ?>" required/>
				
			</li>
			<li>
				<label for="countrycode">Country code:</label>				
				<select class="select-country" data-country= "<?php echo $selected_country = esc_attr( $this->settings['countrycode'] ); ?>" name="<?php echo self::OPTION_NAME; ?>[countrycode]" id="countrycode" required>
					<option>select country</option>
					<option value="AF">Afghanistan</option>
					<option value="AX">Aland Islands</option>
					<option value="AL">Albania</option>
					<option value="DZ">Algeria</option>
					<option value="AS">American Samoa</option>
					<option value="AD">Andorra</option>
					<option value="AO">Angola</option>
					<option value="AI">Anguilla</option>
					<option value="AQ">Antarctica</option>
					<option value="AG">Antigua and Barbuda</option>
					<option value="AR">Argentina</option>
					<option value="AM">Armenia</option>
					<option value="AW">Aruba</option>
					<option value="AU">Australia</option>
					<option value="AT">Austria</option>
					<option value="AZ">Azerbaijan</option>
					<option value="BS">Bahamas</option>
					<option value="BH">Bahrain</option>
					<option value="BD">Bangladesh</option>
					<option value="BB">Barbados</option>
					<option value="BY">Belarus</option>
					<option value="BE">Belgium</option>
					<option value="BZ">Belize</option>
					<option value="BJ">Benin</option>
					<option value="BM">Bermuda</option>
					<option value="BT">Bhutan</option>
					<option value="BO">Bolivia</option>
					<option value="BQ">Bonaire, Sint Eustatius and Saba</option>
					<option value="BA">Bosnia and Herzegovina</option>
					<option value="BW">Botswana</option>
					<option value="BV">Bouvet Island</option>
					<option value="BR">Brazil</option>
					<option value="IO">British Indian Ocean Territory</option>
					<option value="BN">Brunei Darussalam</option>
					<option value="BG">Bulgaria</option>
					<option value="BF">Burkina Faso</option>
					<option value="BI">Burundi</option>
					<option value="KH">Cambodia</option>
					<option value="CM">Cameroon</option>
					<option value="CA">Canada</option>
					<option value="CV">Cape Verde</option>
					<option value="KY">Cayman Islands</option>
					<option value="CF">Central African Republic</option>
					<option value="TD">Chad</option>
					<option value="CL">Chile</option>
					<option value="CN">China</option>
					<option value="CX">Christmas Island</option>
					<option value="CC">Cocos (Keeling) Islands</option>
					<option value="CO">Colombia</option>
					<option value="KM">Comoros</option>
					<option value="CG">Congo</option>
					<option value="CD">Congo, Democratic Republic of the Congo</option>
					<option value="CK">Cook Islands</option>
					<option value="CR">Costa Rica</option>
					<option value="CI">Cote D'Ivoire</option>
					<option value="HR">Croatia</option>
					<option value="CU">Cuba</option>
					<option value="CW">Curacao</option>
					<option value="CY">Cyprus</option>
					<option value="CZ">Czech Republic</option>
					<option value="DK">Denmark</option>
					<option value="DJ">Djibouti</option>
					<option value="DM">Dominica</option>
					<option value="DO">Dominican Republic</option>
					<option value="EC">Ecuador</option>
					<option value="EG">Egypt</option>
					<option value="SV">El Salvador</option>
					<option value="GQ">Equatorial Guinea</option>
					<option value="ER">Eritrea</option>
					<option value="EE">Estonia</option>
					<option value="ET">Ethiopia</option>
					<option value="FK">Falkland Islands (Malvinas)</option>
					<option value="FO">Faroe Islands</option>
					<option value="FJ">Fiji</option>
					<option value="FI">Finland</option>
					<option value="FR">France</option>
					<option value="GF">French Guiana</option>
					<option value="PF">French Polynesia</option>
					<option value="TF">French Southern Territories</option>
					<option value="GA">Gabon</option>
					<option value="GM">Gambia</option>
					<option value="GE">Georgia</option>
					<option value="DE">Germany</option>
					<option value="GH">Ghana</option>
					<option value="GI">Gibraltar</option>
					<option value="GR">Greece</option>
					<option value="GL">Greenland</option>
					<option value="GD">Grenada</option>
					<option value="GP">Guadeloupe</option>
					<option value="GU">Guam</option>
					<option value="GT">Guatemala</option>
					<option value="GG">Guernsey</option>
					<option value="GN">Guinea</option>
					<option value="GW">Guinea-Bissau</option>
					<option value="GY">Guyana</option>
					<option value="HT">Haiti</option>
					<option value="HM">Heard Island and Mcdonald Islands</option>
					<option value="VA">Holy See (Vatican City State)</option>
					<option value="HN">Honduras</option>
					<option value="HK">Hong Kong</option>
					<option value="HU">Hungary</option>
					<option value="IS">Iceland</option>
					<option value="IN">India</option>
					<option value="ID">Indonesia</option>
					<option value="IR">Iran, Islamic Republic of</option>
					<option value="IQ">Iraq</option>
					<option value="IE">Ireland</option>
					<option value="IM">Isle of Man</option>
					<option value="IL">Israel</option>
					<option value="IT">Italy</option>
					<option value="JM">Jamaica</option>
					<option value="JP">Japan</option>
					<option value="JE">Jersey</option>
					<option value="JO">Jordan</option>
					<option value="KZ">Kazakhstan</option>
					<option value="KE">Kenya</option>
					<option value="KI">Kiribati</option>
					<option value="KP">Korea, Democratic People's Republic of</option>
					<option value="KR">Korea, Republic of</option>
					<option value="XK">Kosovo</option>
					<option value="KW">Kuwait</option>
					<option value="KG">Kyrgyzstan</option>
					<option value="LA">Lao People's Democratic Republic</option>
					<option value="LV">Latvia</option>
					<option value="LB">Lebanon</option>
					<option value="LS">Lesotho</option>
					<option value="LR">Liberia</option>
					<option value="LY">Libyan Arab Jamahiriya</option>
					<option value="LI">Liechtenstein</option>
					<option value="LT">Lithuania</option>
					<option value="LU">Luxembourg</option>
					<option value="MO">Macao</option>
					<option value="MK">Macedonia, the Former Yugoslav Republic of</option>
					<option value="MG">Madagascar</option>
					<option value="MW">Malawi</option>
					<option value="MY">Malaysia</option>
					<option value="MV">Maldives</option>
					<option value="ML">Mali</option>
					<option value="MT">Malta</option>
					<option value="MH">Marshall Islands</option>
					<option value="MQ">Martinique</option>
					<option value="MR">Mauritania</option>
					<option value="MU">Mauritius</option>
					<option value="YT">Mayotte</option>
					<option value="MX">Mexico</option>
					<option value="FM">Micronesia, Federated States of</option>
					<option value="MD">Moldova, Republic of</option>
					<option value="MC">Monaco</option>
					<option value="MN">Mongolia</option>
					<option value="ME">Montenegro</option>
					<option value="MS">Montserrat</option>
					<option value="MA">Morocco</option>
					<option value="MZ">Mozambique</option>
					<option value="MM">Myanmar</option>
					<option value="NA">Namibia</option>
					<option value="NR">Nauru</option>
					<option value="NP">Nepal</option>
					<option value="NL">Netherlands</option>
					<option value="AN">Netherlands Antilles</option>
					<option value="NC">New Caledonia</option>
					<option value="NZ">New Zealand</option>
					<option value="NI">Nicaragua</option>
					<option value="NE">Niger</option>
					<option value="NG">Nigeria</option>
					<option value="NU">Niue</option>
					<option value="NF">Norfolk Island</option>
					<option value="MP">Northern Mariana Islands</option>
					<option value="NO">Norway</option>
					<option value="OM">Oman</option>
					<option value="PK">Pakistan</option>
					<option value="PW">Palau</option>
					<option value="PS">Palestinian Territory, Occupied</option>
					<option value="PA">Panama</option>
					<option value="PG">Papua New Guinea</option>
					<option value="PY">Paraguay</option>
					<option value="PE">Peru</option>
					<option value="PH">Philippines</option>
					<option value="PN">Pitcairn</option>
					<option value="PL">Poland</option>
					<option value="PT">Portugal</option>
					<option value="PR">Puerto Rico</option>
					<option value="QA">Qatar</option>
					<option value="RE">Reunion</option>
					<option value="RO">Romania</option>
					<option value="RU">Russian Federation</option>
					<option value="RW">Rwanda</option>
					<option value="BL">Saint Barthelemy</option>
					<option value="SH">Saint Helena</option>
					<option value="KN">Saint Kitts and Nevis</option>
					<option value="LC">Saint Lucia</option>
					<option value="MF">Saint Martin</option>
					<option value="PM">Saint Pierre and Miquelon</option>
					<option value="VC">Saint Vincent and the Grenadines</option>
					<option value="WS">Samoa</option>
					<option value="SM">San Marino</option>
					<option value="ST">Sao Tome and Principe</option>
					<option value="SA">Saudi Arabia</option>
					<option value="SN">Senegal</option>
					<option value="RS">Serbia</option>
					<option value="CS">Serbia and Montenegro</option>
					<option value="SC">Seychelles</option>
					<option value="SL">Sierra Leone</option>
					<option value="SG">Singapore</option>
					<option value="SX">Sint Maarten</option>
					<option value="SK">Slovakia</option>
					<option value="SI">Slovenia</option>
					<option value="SB">Solomon Islands</option>
					<option value="SO">Somalia</option>
					<option value="ZA">South Africa</option>
					<option value="GS">South Georgia and the South Sandwich Islands</option>
					<option value="SS">South Sudan</option>
					<option value="ES">Spain</option>
					<option value="LK">Sri Lanka</option>
					<option value="SD">Sudan</option>
					<option value="SR">Suriname</option>
					<option value="SJ">Svalbard and Jan Mayen</option>
					<option value="SZ">Swaziland</option>
					<option value="SE">Sweden</option>
					<option value="CH">Switzerland</option>
					<option value="SY">Syrian Arab Republic</option>
					<option value="TW">Taiwan, Province of China</option>
					<option value="TJ">Tajikistan</option>
					<option value="TZ">Tanzania, United Republic of</option>
					<option value="TH">Thailand</option>
					<option value="TL">Timor-Leste</option>
					<option value="TG">Togo</option>
					<option value="TK">Tokelau</option>
					<option value="TO">Tonga</option>
					<option value="TT">Trinidad and Tobago</option>
					<option value="TN">Tunisia</option>
					<option value="TR">Turkey</option>
					<option value="TM">Turkmenistan</option>
					<option value="TC">Turks and Caicos Islands</option>
					<option value="TV">Tuvalu</option>
					<option value="UG">Uganda</option>
					<option value="UA">Ukraine</option>
					<option value="AE">United Arab Emirates</option>
					<option value="GB">United Kingdom</option>
					<option value="US">United States</option>
					<option value="UM">United States Minor Outlying Islands</option>
					<option value="UY">Uruguay</option>
					<option value="UZ">Uzbekistan</option>
					<option value="VU">Vanuatu</option>
					<option value="VE">Venezuela</option>
					<option value="VN">Viet Nam</option>
					<option value="VG">Virgin Islands, British</option>
					<option value="VI">Virgin Islands, U.s.</option>
					<option value="WF">Wallis and Futuna</option>
					<option value="EH">Western Sahara</option>
					<option value="YE">Yemen</option>
					<option value="ZM">Zambia</option>
					<option value="ZW">Zimbabwe</option>
				</select>
				
			</li>  
			<li>
				<label for="telareacode" class="checktel">Tel area code:</label>
				<select name="<?php echo self::OPTION_NAME; ?>[telareacode]" class="select-telarea-code" data-country= "<?php echo $selected_telarea_code = esc_attr( $this->settings['telareacode'] ); ?>" id="telareacode" required>
				<option data-countryCode="SG" value="65">Singapore (+65)</option>
				<option data-countryCode="GB" value="44" Selected>UK (+44)</option>
				<option data-countryCode="US" value="1">USA (+1)</option>
					<optgroup label="Other countries">
						<option data-countryCode="DZ" value="213">Algeria (+213)</option>
						<option data-countryCode="AD" value="376">Andorra (+376)</option>
						<option data-countryCode="AO" value="244">Angola (+244)</option>
						<option data-countryCode="AI" value="1264">Anguilla (+1264)</option>
						<option data-countryCode="AG" value="1268">Antigua &amp; Barbuda (+1268)</option>
						<option data-countryCode="AR" value="54">Argentina (+54)</option>
						<option data-countryCode="AM" value="374">Armenia (+374)</option>
						<option data-countryCode="AW" value="297">Aruba (+297)</option>
						<option data-countryCode="AU" value="61">Australia (+61)</option>
						<option data-countryCode="AT" value="43">Austria (+43)</option>
						<option data-countryCode="AZ" value="994">Azerbaijan (+994)</option>
						<option data-countryCode="BS" value="1242">Bahamas (+1242)</option>
						<option data-countryCode="BH" value="973">Bahrain (+973)</option>
						<option data-countryCode="BD" value="880">Bangladesh (+880)</option>
						<option data-countryCode="BB" value="1246">Barbados (+1246)</option>
						<option data-countryCode="BY" value="375">Belarus (+375)</option>
						<option data-countryCode="BE" value="32">Belgium (+32)</option>
						<option data-countryCode="BZ" value="501">Belize (+501)</option>
						<option data-countryCode="BJ" value="229">Benin (+229)</option>
						<option data-countryCode="BM" value="1441">Bermuda (+1441)</option>
						<option data-countryCode="BT" value="975">Bhutan (+975)</option>
						<option data-countryCode="BO" value="591">Bolivia (+591)</option>
						<option data-countryCode="BA" value="387">Bosnia Herzegovina (+387)</option>
						<option data-countryCode="BW" value="267">Botswana (+267)</option>
						<option data-countryCode="BR" value="55">Brazil (+55)</option>
						<option data-countryCode="BN" value="673">Brunei (+673)</option>
						<option data-countryCode="BG" value="359">Bulgaria (+359)</option>
						<option data-countryCode="BF" value="226">Burkina Faso (+226)</option>
						<option data-countryCode="BI" value="257">Burundi (+257)</option>
						<option data-countryCode="KH" value="855">Cambodia (+855)</option>
						<option data-countryCode="CM" value="237">Cameroon (+237)</option>
						<option data-countryCode="CA" value="1">Canada (+1)</option>
						<option data-countryCode="CV" value="238">Cape Verde Islands (+238)</option>
						<option data-countryCode="KY" value="1345">Cayman Islands (+1345)</option>
						<option data-countryCode="CF" value="236">Central African Republic (+236)</option>
						<option data-countryCode="CL" value="56">Chile (+56)</option>
						<option data-countryCode="CN" value="86">China (+86)</option>
						<option data-countryCode="CO" value="57">Colombia (+57)</option>
						<option data-countryCode="KM" value="269">Comoros (+269)</option>
						<option data-countryCode="CG" value="242">Congo (+242)</option>
						<option data-countryCode="CK" value="682">Cook Islands (+682)</option>
						<option data-countryCode="CR" value="506">Costa Rica (+506)</option>
						<option data-countryCode="HR" value="385">Croatia (+385)</option>
						<option data-countryCode="CU" value="53">Cuba (+53)</option>
						<option data-countryCode="CY" value="90392">Cyprus North (+90392)</option>
						<option data-countryCode="CY" value="357">Cyprus South (+357)</option>
						<option data-countryCode="CZ" value="42">Czech Republic (+42)</option>
						<option data-countryCode="DK" value="45">Denmark (+45)</option>
						<option data-countryCode="DJ" value="253">Djibouti (+253)</option>
						<option data-countryCode="DM" value="1809">Dominica (+1809)</option>
						<option data-countryCode="DO" value="1809">Dominican Republic (+1809)</option>
						<option data-countryCode="EC" value="593">Ecuador (+593)</option>
						<option data-countryCode="EG" value="20">Egypt (+20)</option>
						<option data-countryCode="SV" value="503">El Salvador (+503)</option>
						<option data-countryCode="GQ" value="240">Equatorial Guinea (+240)</option>
						<option data-countryCode="ER" value="291">Eritrea (+291)</option>
						<option data-countryCode="EE" value="372">Estonia (+372)</option>
						<option data-countryCode="ET" value="251">Ethiopia (+251)</option>
						<option data-countryCode="FK" value="500">Falkland Islands (+500)</option>
						<option data-countryCode="FO" value="298">Faroe Islands (+298)</option>
						<option data-countryCode="FJ" value="679">Fiji (+679)</option>
						<option data-countryCode="FI" value="358">Finland (+358)</option>
						<option data-countryCode="FR" value="33">France (+33)</option>
						<option data-countryCode="GF" value="594">French Guiana (+594)</option>
						<option data-countryCode="PF" value="689">French Polynesia (+689)</option>
						<option data-countryCode="GA" value="241">Gabon (+241)</option>
						<option data-countryCode="GM" value="220">Gambia (+220)</option>
						<option data-countryCode="GE" value="7880">Georgia (+7880)</option>
						<option data-countryCode="DE" value="49">Germany (+49)</option>
						<option data-countryCode="GH" value="233">Ghana (+233)</option>
						<option data-countryCode="GI" value="350">Gibraltar (+350)</option>
						<option data-countryCode="GR" value="30">Greece (+30)</option>
						<option data-countryCode="GL" value="299">Greenland (+299)</option>
						<option data-countryCode="GD" value="1473">Grenada (+1473)</option>
						<option data-countryCode="GP" value="590">Guadeloupe (+590)</option>
						<option data-countryCode="GU" value="671">Guam (+671)</option>
						<option data-countryCode="GT" value="502">Guatemala (+502)</option>
						<option data-countryCode="GN" value="224">Guinea (+224)</option>
						<option data-countryCode="GW" value="245">Guinea - Bissau (+245)</option>
						<option data-countryCode="GY" value="592">Guyana (+592)</option>
						<option data-countryCode="HT" value="509">Haiti (+509)</option>
						<option data-countryCode="HN" value="504">Honduras (+504)</option>
						<option data-countryCode="HK" value="852">Hong Kong (+852)</option>
						<option data-countryCode="HU" value="36">Hungary (+36)</option>
						<option data-countryCode="IS" value="354">Iceland (+354)</option>
						<option data-countryCode="IN" value="91">India (+91)</option>
						<option data-countryCode="ID" value="62">Indonesia (+62)</option>
						<option data-countryCode="IR" value="98">Iran (+98)</option>
						<option data-countryCode="IQ" value="964">Iraq (+964)</option>
						<option data-countryCode="IE" value="353">Ireland (+353)</option>
						<option data-countryCode="IL" value="972">Israel (+972)</option>
						<option data-countryCode="IT" value="39">Italy (+39)</option>
						<option data-countryCode="JM" value="1876">Jamaica (+1876)</option>
						<option data-countryCode="JP" value="81">Japan (+81)</option>
						<option data-countryCode="JO" value="962">Jordan (+962)</option>
						<option data-countryCode="KZ" value="7">Kazakhstan (+7)</option>
						<option data-countryCode="KE" value="254">Kenya (+254)</option>
						<option data-countryCode="KI" value="686">Kiribati (+686)</option>
						<option data-countryCode="KP" value="850">Korea North (+850)</option>
						<option data-countryCode="KR" value="82">Korea South (+82)</option>
						<option data-countryCode="KW" value="965">Kuwait (+965)</option>
						<option data-countryCode="KG" value="996">Kyrgyzstan (+996)</option>
						<option data-countryCode="LA" value="856">Laos (+856)</option>
						<option data-countryCode="LV" value="371">Latvia (+371)</option>
						<option data-countryCode="LB" value="961">Lebanon (+961)</option>
						<option data-countryCode="LS" value="266">Lesotho (+266)</option>
						<option data-countryCode="LR" value="231">Liberia (+231)</option>
						<option data-countryCode="LY" value="218">Libya (+218)</option>
						<option data-countryCode="LI" value="417">Liechtenstein (+417)</option>
						<option data-countryCode="LT" value="370">Lithuania (+370)</option>
						<option data-countryCode="LU" value="352">Luxembourg (+352)</option>
						<option data-countryCode="MO" value="853">Macao (+853)</option>
						<option data-countryCode="MK" value="389">Macedonia (+389)</option>
						<option data-countryCode="MG" value="261">Madagascar (+261)</option>
						<option data-countryCode="MW" value="265">Malawi (+265)</option>
						<option data-countryCode="MY" value="60">Malaysia (+60)</option>
						<option data-countryCode="MV" value="960">Maldives (+960)</option>
						<option data-countryCode="ML" value="223">Mali (+223)</option>
						<option data-countryCode="MT" value="356">Malta (+356)</option>
						<option data-countryCode="MH" value="692">Marshall Islands (+692)</option>
						<option data-countryCode="MQ" value="596">Martinique (+596)</option>
						<option data-countryCode="MR" value="222">Mauritania (+222)</option>
						<option data-countryCode="YT" value="269">Mayotte (+269)</option>
						<option data-countryCode="MX" value="52">Mexico (+52)</option>
						<option data-countryCode="FM" value="691">Micronesia (+691)</option>
						<option data-countryCode="MD" value="373">Moldova (+373)</option>
						<option data-countryCode="MC" value="377">Monaco (+377)</option>
						<option data-countryCode="MN" value="976">Mongolia (+976)</option>
						<option data-countryCode="MS" value="1664">Montserrat (+1664)</option>
						<option data-countryCode="MA" value="212">Morocco (+212)</option>
						<option data-countryCode="MZ" value="258">Mozambique (+258)</option>
						<option data-countryCode="MN" value="95">Myanmar (+95)</option>
						<option data-countryCode="NA" value="264">Namibia (+264)</option>
						<option data-countryCode="NR" value="674">Nauru (+674)</option>
						<option data-countryCode="NP" value="977">Nepal (+977)</option>
						<option data-countryCode="NL" value="31">Netherlands (+31)</option>
						<option data-countryCode="NC" value="687">New Caledonia (+687)</option>
						<option data-countryCode="NZ" value="64">New Zealand (+64)</option>
						<option data-countryCode="NI" value="505">Nicaragua (+505)</option>
						<option data-countryCode="NE" value="227">Niger (+227)</option>
						<option data-countryCode="NG" value="234">Nigeria (+234)</option>
						<option data-countryCode="NU" value="683">Niue (+683)</option>
						<option data-countryCode="NF" value="672">Norfolk Islands (+672)</option>
						<option data-countryCode="NP" value="670">Northern Marianas (+670)</option>
						<option data-countryCode="NO" value="47">Norway (+47)</option>
						<option data-countryCode="OM" value="968">Oman (+968)</option>
						<option data-countryCode="PW" value="680">Palau (+680)</option>
						<option data-countryCode="PA" value="507">Panama (+507)</option>
						<option data-countryCode="PG" value="675">Papua New Guinea (+675)</option>
						<option data-countryCode="PY" value="595">Paraguay (+595)</option>
						<option data-countryCode="PE" value="51">Peru (+51)</option>
						<option data-countryCode="PH" value="63">Philippines (+63)</option>
						<option data-countryCode="PL" value="48">Poland (+48)</option>
						<option data-countryCode="PT" value="351">Portugal (+351)</option>
						<option data-countryCode="PR" value="1787">Puerto Rico (+1787)</option>
						<option data-countryCode="QA" value="974">Qatar (+974)</option>
						<option data-countryCode="RE" value="262">Reunion (+262)</option>
						<option data-countryCode="RO" value="40">Romania (+40)</option>
						<option data-countryCode="RU" value="7">Russia (+7)</option>
						<option data-countryCode="RW" value="250">Rwanda (+250)</option>
						<option data-countryCode="SM" value="378">San Marino (+378)</option>
						<option data-countryCode="ST" value="239">Sao Tome &amp; Principe (+239)</option>
						<option data-countryCode="SA" value="966">Saudi Arabia (+966)</option>
						<option data-countryCode="SN" value="221">Senegal (+221)</option>
						<option data-countryCode="CS" value="381">Serbia (+381)</option>
						<option data-countryCode="SC" value="248">Seychelles (+248)</option>
						<option data-countryCode="SL" value="232">Sierra Leone (+232)</option>
						<!--option data-countryCode="SG" value="65">Singapore (+65)</option-->
						<option data-countryCode="SK" value="421">Slovak Republic (+421)</option>
						<option data-countryCode="SI" value="386">Slovenia (+386)</option>
						<option data-countryCode="SB" value="677">Solomon Islands (+677)</option>
						<option data-countryCode="SO" value="252">Somalia (+252)</option>
						<option data-countryCode="ZA" value="27">South Africa (+27)</option>
						<option data-countryCode="ES" value="34">Spain (+34)</option>
						<option data-countryCode="LK" value="94">Sri Lanka (+94)</option>
						<option data-countryCode="SH" value="290">St. Helena (+290)</option>
						<option data-countryCode="KN" value="1869">St. Kitts (+1869)</option>
						<option data-countryCode="SC" value="1758">St. Lucia (+1758)</option>
						<option data-countryCode="SD" value="249">Sudan (+249)</option>
						<option data-countryCode="SR" value="597">Suriname (+597)</option>
						<option data-countryCode="SZ" value="268">Swaziland (+268)</option>
						<option data-countryCode="SE" value="46">Sweden (+46)</option>
						<option data-countryCode="CH" value="41">Switzerland (+41)</option>
						<option data-countryCode="SI" value="963">Syria (+963)</option>
						<option data-countryCode="TW" value="886">Taiwan (+886)</option>
						<option data-countryCode="TJ" value="7">Tajikstan (+7)</option>
						<option data-countryCode="TH" value="66">Thailand (+66)</option>
						<option data-countryCode="TG" value="228">Togo (+228)</option>
						<option data-countryCode="TO" value="676">Tonga (+676)</option>
						<option data-countryCode="TT" value="1868">Trinidad &amp; Tobago (+1868)</option>
						<option data-countryCode="TN" value="216">Tunisia (+216)</option>
						<option data-countryCode="TR" value="90">Turkey (+90)</option>
						<option data-countryCode="TM" value="7">Turkmenistan (+7)</option>
						<option data-countryCode="TM" value="993">Turkmenistan (+993)</option>
						<option data-countryCode="TC" value="1649">Turks &amp; Caicos Islands (+1649)</option>
						<option data-countryCode="TV" value="688">Tuvalu (+688)</option>
						<option data-countryCode="UG" value="256">Uganda (+256)</option>
						<!-- <option data-countryCode="GB" value="44">UK (+44)</option> -->
						<option data-countryCode="UA" value="380">Ukraine (+380)</option>
						<option data-countryCode="AE" value="971">United Arab Emirates (+971)</option>
						<option data-countryCode="UY" value="598">Uruguay (+598)</option>
						<!-- <option data-countryCode="US" value="1">USA (+1)</option> -->
						<option data-countryCode="UZ" value="7">Uzbekistan (+7)</option>
						<option data-countryCode="VU" value="678">Vanuatu (+678)</option>
						<option data-countryCode="VA" value="379">Vatican City (+379)</option>
						<option data-countryCode="VE" value="58">Venezuela (+58)</option>
						<option data-countryCode="VN" value="84">Vietnam (+84)</option>
						<option data-countryCode="VG" value="84">Virgin Islands - British (+1284)</option>
						<option data-countryCode="VI" value="84">Virgin Islands - US (+1340)</option>
						<option data-countryCode="WF" value="681">Wallis &amp; Futuna (+681)</option>
						<option data-countryCode="YE" value="969">Yemen (North)(+969)</option>
						<option data-countryCode="YE" value="967">Yemen (South)(+967)</option>
						<option data-countryCode="ZM" value="260">Zambia (+260)</option>
						<option data-countryCode="ZW" value="263">Zimbabwe (+263)</option>
					</optgroup>
				</select>
				
			</li>
			
		</ul>
		<!-- <p class="description"><b>Note:</b> if you find empty labels (page overflows) in print dialogue - use 1mm less height.</p> -->

		<?php
	}

	// #####################
	// ### Label section ###
	// #####################
	function setting_label_size() {
		?>
		<p class="description">The horizontal and vertical sides lenghts of the label.</p>
		<ul>
			<li>
				<label for="label-height">Height :</label>
				<input id="label-height" class="small-text" name="<?php echo self::OPTION_NAME; ?>[label_height]" type="number" min="10"  value="<?php echo esc_attr( $this->settings['label_height'] ); ?>" />
				mm
			</li>
			<li>
				<label for="label-width">Width :</label>
				<input id="label-width" class="small-text" name="<?php echo self::OPTION_NAME; ?>[label_width]" type="number" min="10"  value="<?php echo esc_attr( $this->settings['label_width'] ); ?>" />
				mm
			</li>
		</ul>
		<p class="description"><b>Note:</b> if you find empty labels (page overflows) in print dialogue - use 1mm less height.</p>
		<?php
	}

	function setting_label_padding() {
		?>
			<p class="description">The inner margins of the label.</p>
			<ul>
				<li>
					<label for="label-padding-top-bottom">Top and bottom :</label>
					<input id="label-padding-top-bottom" class="small-text" name="<?php echo self::OPTION_NAME; ?>[label_padding_vertical]" type="number" min="0"  value="<?php echo esc_attr( $this->settings['label_padding_vertical'] ); ?>" />
					mm
				</li>
				<li>
					<label for="label-padding-left-right">Left and right :</label>
					<input id="label-padding-left-right" class="small-text" name="<?php echo self::OPTION_NAME; ?>[label_padding_horizontal]" type="number" min="0"  value="<?php echo esc_attr( $this->settings['label_padding_horizontal'] ); ?>" />
					mm
				</li>
			</ul>
		<?php
	}


	function setting_enable_live_creds() {
		$checked_state = '';
		if ( !empty($this->settings['enable_live_creds']) && $this->settings['enable_live_creds'] == 'on' ) {
			$checked_state = ' checked';
		}
		?>
		
		<label for="enable-live-creds">
		<input id="enable-live-creds" name="<?php echo self::OPTION_NAME; ?>[enable_live_creds]" type="checkbox"<?php echo $checked_state; ?>/>Check to enable live credentials</label>
		<?php
	}


	// #########################
	// ### Recipient section ###
	// #########################
	function setting_recipient_details_layout() {
		$selected_details_layout = esc_html( $this->settings['recipient_details_layout'] );
		?>
		<div class="recipient-details-layout-label-samples-container">
		<?php
		// Output the radio buttons field, its options and set the selected option.
		foreach ($this->recipient_details_layout_options as $key => $value) {
			if ($key == $selected_details_layout) {
				echo '<div class="recipient-details-layout-label-sample"><input type="radio" id="' . $key . '-recipient-details-layout-option" name="' . self::OPTION_NAME . '[recipient_details_layout]" value="' . $key . '" checked="checked"><label for="' . $key . '-recipient-details-layout-option">' . $value . '</label></div>';
			} else {
				echo '<div class="recipient-details-layout-label-sample"><input type="radio" id="' . $key . '-recipient-details-layout-option" name="' . self::OPTION_NAME . '[recipient_details_layout]" value="' . $key . '"><label for="' . $key . '-recipient-details-layout-option">' . $value . '</label></div>';
			}
		}
		?>
		</div>
		<?php
	}

	function setting_recipient_details_align() {
		$selected_align_option = esc_html( $this->settings['recipient_align_fields'] );
		// Output the select field, its options and set the selected option.
		?>
		<select name="<?php echo self::OPTION_NAME; ?>[recipient_align_fields]">
			<?php
			foreach ($this->recipient_align_fields_options as $value) {
				if ($value == $selected_align_option) {
					echo '<option selected="selected" value="' . $value . '">' . $value. '</option>';
				} else {
					echo '<option value="' . $value . '">' . $value. '</option>';
				}
			}
			?>
		</select>
		<?php
	}

	function setting_recipient_show_company() {
		$checked_state = '';
		if ( !empty($this->settings['show_company']) && $this->settings['show_company'] == 'on' ) {
			$checked_state = ' checked';
		}
		?>
		<label for="show-company">
		<input id="show-company" name="<?php echo self::OPTION_NAME; ?>[show_company]" type="checkbox"<?php echo $checked_state; ?>/>Show company field if not empty</label>
		<p class="description"><b>Note:</b> this field might confuse the shipping carrier, if the company employee ships it to his personal address.</p>
		<?php
	}

	function setting_recipient_display_state_full_name() {
		$checked_state = '';
		if ( !empty($this->settings['display_state_full_name'] )  && $this->settings['display_state_full_name'] == 'on'  ) {
			$checked_state = ' checked';
		}
		?>
		<label for="display-state-full-name">
		<input id="display-state-full-name" name="<?php echo self::OPTION_NAME; ?>[display_state_full_name]" type="checkbox"<?php echo $checked_state; ?>/>Display state full name</label>
		<?php
	}

	function setting_recipient_hide_base_country() {
		$checked_state = '';
		if ( !empty($this->settings['hide_base_country'] )  && $this->settings['hide_base_country'] == 'on'  ) {
			$checked_state = ' checked';
		}
		?>
		<label for="hide-base-country">
		<input id="hide-base-country" name="<?php echo self::OPTION_NAME; ?>[hide_base_country]" type="checkbox"<?php echo $checked_state; ?>/>Hide country field when shipping to store base country</label>
		<p class="description">Store base country is a setting set in <b>WooCommerce</b> > <b>Settings</b> > <b>General</b> > <b>Store Address</b></p>
		<?php
	}

	function setting_recipient_show_phone() {
		$checked_state = '';
		if ( !empty($this->settings['show_phone']) && $this->settings['show_phone'] == 'on' ) {
			$checked_state = ' checked';
		}
		?>
		<label for="show-phone">
		<input id="show-phone" name="<?php echo self::OPTION_NAME; ?>[show_phone]" type="checkbox"<?php echo $checked_state; ?>/>Show phone field if not empty</label>
		<?php
	}

	function setting_recipient_use_billing_details() {
		$checked_state = '';
		if ( !empty($this->settings['use_billing_details']) && $this->settings['use_billing_details'] == 'on' ) {
			$checked_state = ' checked';
		}
		?>
		<label for="use-billing-details">
		<input id="use-billing-details" name="<?php echo self::OPTION_NAME; ?>[use_billing_details]" type="checkbox"<?php echo $checked_state; ?>/>Use billing details if shipping details are empty</label>
		<p class="description">Some themes hide the shipping details section of checkout form, leaving them empty in order details.</p>
		<?php
	}


	function setting_order_show_id() {
		$checked_state = '';
		if ( !empty($this->settings['show_order_id']) && $this->settings['show_order_id'] == 'on' ) {
			$checked_state = ' checked';
		}
		?>
		<label for="show-order-id">
		<input id="show-order-id" name="<?php echo self::OPTION_NAME; ?>[show_order_id]" type="checkbox"<?php echo $checked_state; ?>/>Show order id</label>
		<?php
	}

	function setting_order_show_total() {
		$checked_state = '';
		if ( !empty($this->settings['show_order_total']) && $this->settings['show_order_total'] == 'on' ) {
			$checked_state = ' checked';
		}
		?>
		<label for="show-order-total">
		<input id="show-order-total" name="<?php echo self::OPTION_NAME; ?>[show_order_total]" type="checkbox"<?php echo $checked_state; ?>/>Show order total (some shipping carriers require this info)</label>
		<?php
	}



	  ///////////////////////////////
	 /// WooCommerce orders page ///
	///////////////////////////////
	/**
	 * Add custom column to WooCommerce orders table page.
	 */
	function add_print_buttons_column( $columns ) {
		$columns['shipping_label'] = __('Shipping Labels');
		return $columns;
	}

	/**
	 * Populate the column with print buttons.
	 */
	function add_print_buttons( $column ) {
		global $post;

		if ( $column === 'shipping_label' ) {
			$shipping_label_print_button_html = '<button type="button" class="button button-sslabels-print" '
			. 'value="' . $post->ID . '">'. __( 'Label' ) .'</button>';
			echo $shipping_label_print_button_html;
		}
	}


	/**
	 * Add JavaScript functionality to the "Print" buttons on the WooCommerce orders page.
	 * We enqueue the JavaScript script on that specific page (also known as the 'shop_order' screen).
	 * Then we pass it the plugin settings and additional style and script files paths to apply
	 * to the generated page of labels.
	 * We use wp_localize_script() to pass PHP variables to the enqueued JavaScript
	 */
	function add_admin_pages_scripts_and_styles( $hook ) {
		if ( ! is_user_logged_in() ) exit;

		$current_screen = get_current_screen();

		// Here we pass the stored options or default values to the orders page JavaScript,
		// for it to generate a shipping labels page with correct settings.
		if ( ($hook == 'edit.php' || $hook == 'post.php' ) && $current_screen->post_type == 'shop_order' ) {

			// Add JavaScript functionality to the main orders page,
			// for the Shipping Labels column 'Print' buttons to use.
			wp_enqueue_script( 'shipping-label-script', plugins_url( '/js/woocommerce-orders.js', __FILE__ ) );

			// Get the plugin settings options for JavaScript to generate customized labels, and pass it
			// to the enqueued JavaScript sctipt.

				$labels_page_localized_js_object = array(
					'_ajax_nonce'					=> wp_create_nonce('generate_labels'),
					'button_name'			=> __( 'Label' ),
					'button_active_name'	=> __( 'Generating' ) . '...'
				);
				wp_localize_script( 'shipping-label-script', 'sslabels', $labels_page_localized_js_object );
				wp_enqueue_style( 'sslabels-stylesheet', plugins_url( '/css/options-page-style.css', __FILE__ ) );
			

		// Enqueue settings page scripts and stylesheet.
		} else if ( !empty($_GET['page']) && $_GET['page'] == self::SETTINGS_PAGE_SLUG ) {
			wp_enqueue_style( 'sslabels-stylesheet', plugins_url( '/css/options-page-style.css', __FILE__ ) );
			wp_enqueue_script( 'sslabels-pro-settings-script',  plugins_url( '/js/settings-page.js', __FILE__ ) );
		}
	}


	  ///////////////////////////////////
	 /// AJAX callbacks (plugin API) ///
	///////////////////////////////////
	/**
	 * Plugin AJAX endpoint that acts as the plugin API for the following actions:
	 * - Generate and return labels page for a list of order ids.
	 * - Reset plugin setting - remove store plugin settings option for wp_options database table and set the $settings field to $default_settings.
	 */
	function sslabels_api() {

		// Security checklist:
		// 1) API action exists.
		// 2) Verify nonce.
		// 3) Check user capabilities.
		// 4) Sanitize and Validate input.
		// 5) Escape output.
		$allowed_api_actions = [ 'generate_labels', 'reset_options' ];

		// If no 'api_action' or nonces exist in requesy - exit immediately.
		if ( empty( $_REQUEST['api_action'] ) || empty( $_REQUEST['_ajax_nonce'] ) ) {
			exit;
		}

		// Do the correct api action.
		switch($_REQUEST['api_action']) {

			case 'generate_labels':
				if (wp_verify_nonce( $_REQUEST['_ajax_nonce'], 'generate_labels' ) &&
					current_user_can('edit_posts') &&
					!empty($_POST['orders']) ) {

					// Sanitize an array or comma/space-separated list of IDs (WooCommerce orders IDs in this case).
					$orders = wp_parse_id_list( $_POST['orders'] );		// Uses absint() to convert a value to non-negative integer.

					// Generate response HTML.
					$this->generate_shipping_labels_page_html( $orders );
				}
				break;

			case 'reset_options':
				if (wp_verify_nonce( $_REQUEST['_ajax_nonce'], 'reset_options' ) && current_user_can('manage_options') ) {
					delete_option( self::OPTION_NAME );
				}
				break;
			default:
				wp_die();
		}

		wp_die(); // This is required to terminate immediately and return a proper response.
	}


	  //////////////////////////////////////////////////////
	 /// Plugin activation, version control and updates ///
	//////////////////////////////////////////////////////

	/**
	 * Load plugin option stored in dastabase (array of settings), check plugin version and run update procedures if necessary.
	 */
	function load_plugin_settings() {

		// Look for a stored plugin option in database (this option is an array/dictionary of plugin settings).
		$stored_option = get_option( self::OPTION_NAME );

		//print_r($stored_option);

		// If option exists in database - check the version.
		if ($stored_option) {

			// Compare the default/required plugin settings to the stored settings.
			if (!empty(array_diff_key($this->default_settings, $stored_option))) {
				// We reach this section only if the stored plugin option found in database doesn't have all the keys as the default settings array.
				// So in this section we can run any version related update procedures.

				// We create a new options array to store in database, by looping over the default settings (which current plugin version requires),
				// add the ones that exist in stored options, then add the ones that don't from current version default settings.
				$new_option_to_save = array();
				foreach ($this->default_settings as $key => $value) {
					if (array_key_exists($key, $stored_option)) {
						$new_option_to_save[$key] = $stored_option[$key];
					} else {
						$new_option_to_save[$key] = $value;
					}
				}

				// Since 'plugin_version' exists in $stored_option - it is set in foreach loop above, so we update the value here.
				$new_option_to_save['plugin_version'] = self::PLUGIN_VERSION;

				// Set the settings variable for the plugin to use the updated option.
				$this->settings = $new_option_to_save;
				//echo self::OPTION_NAME;
				// Update the database option.
				//update_option( 'self::OPTION_NAME', $new_option_to_save);
				add_option( 'self::OPTION_NAME', $new_option_to_save);

			// If all required settings are present - set the settings variable for the plugin to use the stored option.
			} else {
				$this->settings = $stored_option;
			}

		// Else - no option found in database, so just use the plugin default settings.
		} else {
			$this->settings = $this->default_settings;
		}
	}


	  /////////////////////////////////////////
	 /// Client labels page pop-up content ///
	/////////////////////////////////////////
	/**
	 * If a string contains Hebrew/Arabic characters - return a CSS class that is
	 * used to style rtl fields.
	 */
	function rtl_css_class($str) {
		$pattern = '/[\x{0591}-\x{07FF}\x{FB1D}-\x{FDFD}\x{FE70}-\x{FEFC}]/u';

		if ( preg_match($pattern, $str) )
		{
			return " rtl";
		} else {
			return "";
		}
	}


	/**
	 * Output HTML for shipping labels page.
	 * The HTML is used as the content of a client pop-up tab/window,
	 * created by JavaScript in client browser, for the client to print.
	 */
	function generate_shipping_labels_page_html( $orders ) {
		?>
		<style>
		/* Page style */
		body {
			background-color: rgb(210, 214, 220);
			margin: 0px;
			padding: 0px;
		}

		/* Label style */
		.shipping-label {
			position: relative;
			box-sizing: border-box;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			width: <?php echo esc_html( $this->settings['label_width'] ) ?>mm;
			height: <?php echo esc_html( $this->settings['label_height'] ) ?>mm;
			padding: <?php echo esc_html( $this->settings['label_padding_vertical'] ) . "mm " . esc_html( $this->settings['label_padding_horizontal'] ) ."mm" ?>;
			margin: 20px;
			border-radius: 3mm;
			background-color: white;
			box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15);
			font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;
		}

		/* Support for WordPress image alignment classes */
		.alignleft {
			float: left;
		}

		.alignright {
			float: right;
		}

		.aligncenter {
			display: block;
			margin-left: auto;
			margin-right: auto;
		}

		.recipient-container {
			flex: 1;
			width: 100%;
			display: flex;
			flex-direction: column;
			align-items: center;
			overflow: hidden;
		}

		.detail-container {
			flex: 1;
			box-sizing: border-box;
			display: flex;
			align-items: center;
			width: 100%;
			border: none;
			padding: 0px;
			margin: 0px;
			background-color: transparent;
			overflow: hidden;
		}

		.detail {
			background-color: transparent;
			box-sizing: border-box;
			overflow: hidden;
			resize: none;
		}

		[contenteditable]:focus {
			outline: none;
			background-color: rgb(195,207,221);
			color: black;
		}
		.btn {
			background: #2271b1;
			border-color: #2271b1;
			color: #fff;
			text-decoration: none;
			text-shadow: none;
			padding: 10px;
			border-radius: 3px;
		}
		.print-link{
			padding: 5px;
		}

		/* Customer details style */
		<?php
		// Customer fields alignment.
		$selected_align = $this->settings['recipient_align_fields'];
		if ($selected_align == "left") {
			echo '.detail { text-align: left; } .detail-container { justify-content: flex-start; }';
		} else if ($selected_align == "right") {
			echo '.detail { text-align: right; } .detail-container { justify-content: flex-end; }';
		} else {
			echo '.detail { text-align: center; } .detail-container { justify-content: center; }';
		}
		?>

		.rtl {
			direction: rtl;
		}

		.name {
			flex: 1.5;
			font-weight: bold;
		}

		.address {
			flex: 1.5;
		}

		.country {
			font-weight: bold;
		}

		.phone {
			align-items: baseline;
		}

		.order-id {
			vertical-align: text-top;
			height: fit-content;
			width: fit-content;
			position: absolute;
			right: 15px;
			bottom: 10px;
			font-size: 16px;
		}

		/*** Print style - hide redundant elements and styles ***/
		@media print {
			body {
				background-color: initial;
			}

			.shipping-label {
				page-break-after: always;
				border: none;
				border-radius: initial;
				box-shadow: none;
				margin: 0px;
			}
		}
		</style>
		
		<?php

		// Get store base country to check whether a given order shipping is local or international.
		$store_base_country = WC()->countries->get_base_country();

		// The string to use for order total, will get tranlated to local shipping to base country.
		$order_total_field_string = "Order Total";
		$order_total_field_label_original_locale = __($order_total_field_string, 'woocommerce');

		// Generate shipping label HTML for each order_id.
		foreach ($orders as $order_id)
		{
			// Try to get the WooCommerce order corresponding to the current order id (instance of WC_Order object).
			$order = wc_get_order( $order_id );

			// If current order id doesn't exist - continue to generating next order label.
			if (!$order) {
				continue;
			}

			// Get the customer shipping information details.
			$order_number		= $order->get_order_number();
			$order_first_name	= $order->get_shipping_first_name();
			$order_last_name	= $order->get_shipping_last_name();
			$order_company		= $order->get_shipping_company();
			$order_address_1	= $order->get_shipping_address_1();
			$order_address_2	= $order->get_shipping_address_2();
			$order_city			= $order->get_shipping_city();
			$order_state		= $order->get_shipping_state();
			$order_postcode		= $order->get_shipping_postcode();
			$order_country		= $order->get_shipping_country();
			$order_phone		= $order->get_shipping_phone();

			// Temporary fix - WooCommerce 5.6 introduced get_shipping_phone() method, but doesn't duplicate billing phone field to shipping phone field
			// (as it does for other fields) and themes don't yet expose the shipping phone field when "Ship to a different address?" checkbox in chechout is checked.
			// So we still use the billing phone if shipping phone is empty.
			if (empty($order_phone)) {
				$order_phone = $order->get_billing_phone();
			}

			if ( !empty($this->settings['use_billing_details']) && $this->settings['use_billing_details'] == 'on' && empty($order_first_name) ) {
				$order_first_name	= $order->get_billing_first_name();
				$order_last_name	= $order->get_billing_last_name();
				$order_company		= $order->get_billing_company();
				$order_address_1	= $order->get_billing_address_1();
				$order_address_2	= $order->get_billing_address_2();
				$order_city			= $order->get_billing_city();
				$order_state		= $order->get_billing_state();
				$order_postcode		= $order->get_billing_postcode();
				$order_country		= $order->get_billing_country();
				$order_phone		= $order->get_billing_phone();
			}

			// For international shipping (shipping country != store base country)
			// get shipping country and state in English, by temporary switching WordPress environment locale.
			$is_shipping_to_base_country = $store_base_country === $order_country;

			// Declare result containers.
			$country;
			$state;

			// If shipping to local address - use default WordPress $locale='default' language for local country, state and "Order total" field string.
			if ( $is_shipping_to_base_country ) {

				// Get full country name.
				$country = WC()->countries->countries[$order_country];

				// Get full state name (if option 'display_state_full_name' in on), otherwise use order state abbreviation.
				if ( !empty($this->settings['display_state_full_name']) && $this->settings['display_state_full_name'] == 'on' ) {
					$state  = !empty(WC()->countries->get_states($order_country)) ? WC()->countries->get_states($order_country)[$order_state] : '';
				} else {
					$state = $order_state;
				}

				// Set order total local label.
				$order_total_field_label = $order_total_field_label_original_locale;

			// Else - switch to $locale='en_US' to generate international shipping labels in English.
			} else {
				// Switch locale (WordPress language for translations) to get countries list in English, using WordPress locale_switcher.
				$locale_switched = switch_to_locale( 'en_US' );

				// Get translated full country name, using WooCommerce countries.php file array.
				$countries = include WC()->plugin_path() . '/i18n/countries.php';
				$country = $countries[$order_country];

				// Get translated full state name (if option 'display_state_full_name' in on) using WooCommerce states.php file array,
				// otherwise use order state abbreviation.
				if ( !empty($this->settings['display_state_full_name']) && $this->settings['display_state_full_name'] == 'on' ) {
					$state  = !empty(WC()->countries->get_states($order_country)) ? WC()->countries->get_states($order_country)[$order_state] : '';

					// Alternative way to get states:
					//$states = include WC()->plugin_path() . '/i18n/states.php';
					//$state = !empty($states[$order_country]) ? $states[$order_country][$order_state] : '';
				} else {
					$state = $order_state;
				}

				// When we are done, restore the initial WordPress locale.
				restore_current_locale();

				// Set order total international label.
				$order_total_field_label = $order_total_field_string;
			}

			// Generate current order shipping label element and append to the HTML result string.
			// To support Right-to-Left data, we asign ".rtl" class (for css direction/aligning styles) to all fields
			// containing RTL characters. To find those characters, we use Regex (regular expression) patterns in
			// $this->rtl_css_class() function.
			?>
					<?php

					/* label generation */
					
					include_once 'label/label.php';

					//To trace order in admin order page
					//include_once 'label/tracktrace.php';

					?>
					<!-- <div class="detail-container address"><div contenteditable="true" class="detail<?php echo $this->rtl_css_class($order_address_1) ?>"><?php echo esc_html( $order_address_1 ) . ( (strlen($order_address_2) == 0) ? "" : "&nbsp;" . esc_html( $order_address_2 ) ) ?></div></div> -->
					
			<?php
		}

		?>
		<script>
			document.addEventListener('DOMContentLoaded', simpleShippingLabelsPageOnLoaded);

			/**
			 * This function adds custom 'input' event to trigger auto text fitting script
			 * when user edits any label field. It also triggers the attached event to intiaily
			 * fit text in each detail field.
			 */
			function simpleShippingLabelsPageOnLoaded() {
				var details = document.querySelectorAll('.detail');
				var event = new Event('input', {
					bubbles: true,
					cancelable: true,
				});
				for (let i = 0; i < details.length; i++) {
					details[i].addEventListener('paste', simpleShippingLabelsPasteHandler);
					details[i].addEventListener('input', simpleShippingLabelsFitInput);
					details[i].dispatchEvent(event);
				}

				var orderId = document.querySelector('.order-id');
				if (orderId != null) {
					orderId.addEventListener('paste', simpleShippingLabelsPasteHandler);
				}

			}

			/**
			 * Handle pasting formatted text by pasting as plain text.
			 * This prevents the fit input function from freaking out and freezing the window.
			 */
			function simpleShippingLabelsPasteHandler(e) {

				// Prevent default paste (might by formatted text).
				e.preventDefault();

				// Get text representation of clipboard.
				let pasted_text = (event.clipboardData || window.clipboardData).getData('text');

				// Insert text manually (this command maintaince input history).
				document.execCommand("insertText", true, pasted_text);
			}

			/**
			 * This function tests elements content overflow/available space to grow and adjusts
			 * the font size accordingly.
			 */
			function simpleShippingLabelsFitInput() {
				while ( (this.innerText.length > 0) && (this.clientWidth < this.parentElement.clientWidth) && (this.clientHeight < this.parentElement.clientHeight) ) {
					this.style.fontSize = parseFloat(window.getComputedStyle(this).fontSize) + 0.3 + 'px';
				}
				while ( (this.clientWidth > this.parentElement.clientWidth) || (this.clientHeight > this.parentElement.clientHeight) ) {
					this.style.fontSize = parseFloat(window.getComputedStyle(this).fontSize) - 0.3 + 'px';
				}
			}
		</script>
		</body>
		<?php
	}


}

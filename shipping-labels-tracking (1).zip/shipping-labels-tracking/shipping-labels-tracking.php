<?php

// Exit if this file is accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Plugin Name:       Shipping Labels and Tracking
 * Description:       To generate a shipping label and tracking in woocommerce order page.
 * Version:           1.0.0
 * Author:            Developer Singh
 * License:           GPLv3
 */


/**
 *** How this plugin works and what it does:
 * 1) The plugin has an OOP structure so it's easier to maintain (no stupid prefixing to prevent name clashing).
 * 2) Adds a settings page to the WooCommerce submenu in WordPress admin dashboard.
 * 2) Adds a button in WooCommerce orders page.
 * 3) Clicking a button makes an AJAX call to the plugin registered AJAX function to generate the shipping labels
 *    php page. Then JavaScript creates new browser tab and sets its content to the response. The user can then
 *    edit the generated labels and print the page.
 */

// This plugin is for site administrators only, so we load the plugin only in admin mode.
if ( is_admin() ) {
    
    // Load plugin class code.
    require_once __DIR__ . '/label_generation/label_generation.php';

    require_once  __DIR__ . "/label_generation/signature/BizMsgCrypt.php";

    // Create plugin class instance.
    // Provide the plugin basename to the constructor for adding plugin actions to the plugins page table (like a link to the plugin Settings page).
    $shippingLabelstracking = new shippingLabelstracking( plugin_basename(__FILE__) );
    
}

/* To track the order and show tracking code in my account -> order detail page frontend */
require_once __DIR__ . '/label_generation/tracking.php';
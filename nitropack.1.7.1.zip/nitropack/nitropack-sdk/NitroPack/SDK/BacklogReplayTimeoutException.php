<?php
namespace NitroPack\SDK;

class BacklogReplayTimeoutException extends \RuntimeException {}

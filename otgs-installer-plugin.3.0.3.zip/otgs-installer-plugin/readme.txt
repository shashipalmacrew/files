=== OTGS Installer Plugin ===
Stable tag: 3.0.3
# Changelog

## 3.0.3
- Preselect Toolset Types and Toolset Blocks if no other Toolset plugin is installed.

## 3.0.2
- Do not show "Register ..." for plugins, which are free on wordpress.org.

## 3.0.1
- Show button "Install WPML Multilingual CMS" instead of the list of all plugin when WPML is not installed yet.

## 3.0.0
- Updating installer library and adjusting plugin version.

## 1.0.0

- Lightweight Installer plugin that allows to install OTGS plugins.
